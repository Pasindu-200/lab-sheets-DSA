import java.util.Random;

class SelectionSortArray {
    private long[] a;
    private int nElems;


    public SelectionSortArray(int size) {
        a = new long[size];
        nElems = 0;
    }

    public void insert(long value) {
        if (nElems < a.length) {
            a[nElems] = value;
            nElems++;
        } else {
            System.out.println("Array is full, cannot insert more elements.");
        }
    }


    public void selectionSort() {
        for (int i = 0; i < nElems - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < nElems; j++) {
                if (a[j] < a[minIndex]) {
                    minIndex = j;
                }
            }
            swap(i, minIndex);
        }
    }

    private void swap(int i, int j) {
        long temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }


    public void display() {
        for (int i = 0; i < nElems; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int size = 10000;
        SelectionSortArray arr = new SelectionSortArray(size);
        Random rand = new Random();


        for (int i = 0; i < size; i++) {
            arr.insert(rand.nextInt(1000000) + 1);
        }


        long startTime = System.nanoTime();
        arr.selectionSort();
        long endTime = System.nanoTime();
        System.out.println("Execution time for Selection Sort: " + (endTime - startTime) / 1_000_000.0 + " ms");


        startTime = System.nanoTime();
        arr.insert(rand.nextInt(1000000) + 1);
        endTime = System.nanoTime();
        System.out.println("Execution time for inserting an element: " + (endTime - startTime) / 1_000_000.0 + " ms");

        arr.display();
    }
}

