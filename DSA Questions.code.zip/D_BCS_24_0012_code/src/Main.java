
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        System.out.println("\nWelcome to the CFR System !!!");

        // Getting max array size and Instance the 'customerFeedbackSystem' class
        Scanner s1 = new Scanner(System.in);
        int max;
        do {
            System.out.print("\nEnter maximum array limit:- ");
            max = s1.nextInt();
            if (max <=0) {
                System.out.println("Maximum array limit should be exceeded 0 !!!");
            }
        } while (max <= 0);
        customerFeedbackSystem CFR = new customerFeedbackSystem(max);

        // Main menu
        int mainMenuChoice;
        do {
            System.out.println("\n\nCFR System Main menu !!!");
            mainMenuChoice = CFR.menuInput();
            switch (mainMenuChoice) {
                case 1:
                    CFR.addCustomerRating();
                    break;
                case 2:
                    CFR.findRating();
                    break;
                case 3:
                    CFR.showAllRatings();
                    break;
                case 4:
                    CFR.deleteCustomerRating();
                    break;
                case 5:
                    System.out.println();
                    System.out.println("Eliminating the CFR system !!!");
                    System.out.println("Thank you for using the CFR System...");
                    break;
            }
        } while (mainMenuChoice != 5);
    }
}