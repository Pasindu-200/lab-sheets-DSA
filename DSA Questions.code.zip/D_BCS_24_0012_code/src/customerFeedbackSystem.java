
import java.util.Scanner;   // To get user inputs
import java.util.Random;    // To generate random index values

public class customerFeedbackSystem {

    Scanner s1 = new Scanner(System.in);
    private final int[] customerFeedback;
    private int CFElems;        // Focus on the next writable index in array
    private final int[] validRating = {1, 2, 3, 4, 5};  // Valid customer ratings

    // variables for calculate response time
    long startTime, stopTime;

    public customerFeedbackSystem(int max) {
        customerFeedback = new int[max];
        CFElems = 0;
    }

    public int menuInput() {
        boolean invalidInput;
        int input;

        // The menu items
        System.out.println("Enter [1] to add a new customer feedback rating.");
        System.out.println("Enter [2] to find a first occurrence of specific rating.");
        System.out.println("Enter [3] to show all customer feedback rating");
        System.out.println("Enter [4] delete all occurrences of specific rating.");
        System.out.println("Enter [5] to eliminate the program.");

        do {
            System.out.print("Enter your choice:- ");
            input = s1.nextInt();
            invalidInput = ((input >= 1) && (input <= 5) ? false : true);
            if (invalidInput) {
                System.out.println("Invalid input. Try again.");
            }
        } while (invalidInput);

        System.out.println();
        return input;
    }

    // Search rating - use within the class - search key, array number
    // 1 - customerFeedback
    // 2 - validRating
    private int searchCustomerFeedback(int search, int array) {
        for (int i = 0; i < (array==1? CFElems:5); i++) {
            if ((array==1? customerFeedback[i]:validRating[i]) == search) {
                return i;
            }
        }
        return -1;
    }

    // Search the existence of a rating
    public void findRating() {
        if (notNullArray()) {
            System.out.print("Enter the rating that you want to find:- ");
            int rating = s1.nextInt();

            // Response timer start
            startTime = System.nanoTime();

            // process
            int firstOccurrenceIndex = searchCustomerFeedback(rating, 1);

            // Response timer stop
            stopTime = System.nanoTime();

            if (!(firstOccurrenceIndex < 0)) {
                System.out.println("Customer feedback found(" + rating + ").\nFirst occurrence rating number:- " + (firstOccurrenceIndex + 1));
            } else {
                System.out.println("Customer feedback not found(" + rating + ").");
            }

            // Display response time
            System.out.println("Response time:- " + String.format("%,d",stopTime-startTime) + " nanoseconds\n");

        }
    }

    // Enter customer rating as user inputs - integer
    private int getUserInput() {
        int userRating;
        do {
            System.out.print("Enter the user rating value:- ");
            userRating = s1.nextInt();
            if (searchCustomerFeedback(userRating, 2)<0) {
                System.out.println("Invalid input. Try again[1-5].");
            }
        } while (searchCustomerFeedback(userRating, 2)<0);
        return userRating;
    }

    // Enter customer rating as random selection by the computer - For testing purpose
    private int getRandomInput() {
        Random R1 = new Random();
        // getting random index and return relevant element in the array
        return validRating[R1.nextInt(validRating.length)];
    }


    // 1st option ---> "Add new customer rating."
    public void addCustomerRating() {
        int CRCount, subMenuChoice;

        if (!(customerFeedback.length == CFElems)) {

            System.out.println("\n");
            System.out.println("Enter [1] to add a new customer feedback as user inputs.");
            System.out.println("Enter [2] to add a new customer feedback as randomly by computer.");
            System.out.println("Enter [3] Back to main menu.");

            do {
                System.out.print("Enter your choice:- ");
                subMenuChoice = s1.nextInt();
                if (!(subMenuChoice >= 1 && subMenuChoice <= 3)) {
                    System.out.println("Invalid input. Try again[1-3].");
                }
            } while (!(subMenuChoice >= 1 && subMenuChoice <= 3));

            // If user enter third choice - Redirect to the main menu
            if (subMenuChoice == 3) {
                System.out.println("Redirecting to the main menu...");
                return;
            }

            // check the rating count is in the valid insert range
            do {
                System.out.print("\nEnter the customer rating count that should be added:- ");
                CRCount = s1.nextInt();
                if (CRCount > (customerFeedback.length - CFElems)) {
                    System.out.println("Can't exceed array length(" + customerFeedback.length + ") !!!");
                } else if (CRCount == 0) {
                    System.out.println("Redirecting to the main menu...");
                    return;
                } else if (CRCount < 0) {
                    System.out.println("Input data is invalid !!!");
                } else {
                    break;
                }
            } while (true);

            System.out.println();

            // Time counter starting point for computer generated values
            // Response time for insert all randomly computer generated values
            if (subMenuChoice == 2) {
                // Response timer start
                startTime = System.nanoTime();
            }

            for (int i = 0, temp_rate; i < CRCount; i++) {
                if (subMenuChoice == 1) {

                    temp_rate = getUserInput();

                    // Time counter starting point for user input
                    // Response time for each inserted user input
                    // Response timer start
                    startTime = System.nanoTime();

                } else {
                    temp_rate = getRandomInput();
                }

                // Process
                customerFeedback[CFElems++] = temp_rate;

                if (subMenuChoice == 1) {
                    // Time counter stop point for user input
                    // Response time for each inserted user input
                    // Response timer stop
                    stopTime = System.nanoTime();
                }

                System.out.println("Rating '" + temp_rate + "' was successfully added.");

                if (subMenuChoice == 1) {
                    // Display response time
                    System.out.println("Response time:- " + String.format("%,d",stopTime-startTime) + " nanoseconds\n");
                }
            }

            // Time counter stop point for computer generated values
            // Response time for insert all randomly computer generated values
            if (subMenuChoice == 2) {
                // Response timer stop
                stopTime = System.nanoTime();

                // Display response time
                System.out.println("Response time:- " + String.format("%,d",stopTime-startTime) + " nanoseconds\n");
            }

        } else {
            System.out.println("Array is full. Remove elements or restart the programme !");
        }
    }

    // if the array is empty stop operations and direct user to ---> "Add ratings number"
    private boolean notNullArray() {
        if (CFElems == 0) {
            System.out.println("No rating were found. Add new customer ratings first !!!");
            return false;
        } else {
            return true;
        }
    }

    // Show all the ratings that in the valid range
    public void showAllRatings() {
        if (notNullArray()) {
            System.out.println("\nAll customer feedback ratings...");

            // Response timer start
            startTime = System.nanoTime();

            // Process
            for (int i = 0; i < CFElems; i++) {
                System.out.print((customerFeedback[i]) + ((((i + 1) % 10) == 0) ? "\n" : "\t"));
            }

            // Response timer stop
            stopTime = System.nanoTime();

            // Display response time
            System.out.println("Response time:- " + String.format("%,d",stopTime-startTime) + " nanoseconds\n");
        }
    }

    // Delete all the occurrences of the specific rating
    public void deleteCustomerRating() {
        if (notNullArray()) {
            System.out.println("Delete customer feedback ratings...");
            int CRNumDelete = getUserInput();

            // Response timer start
            startTime = System.nanoTime();

            int deletedElementCount = 0;
            for (int i = searchCustomerFeedback(CRNumDelete, 1); i < CFElems; i++) {
                if (i<0) { break; }
                if (customerFeedback[i] == CRNumDelete) {
                    for (int j = i; j < CFElems-1; j++) {
                        customerFeedback[j] = customerFeedback[j + 1];
                    }
                    CFElems--;
                    i--;
                    deletedElementCount++;
                }
            }
            if (deletedElementCount > 0) {
                System.out.println(deletedElementCount + ((deletedElementCount == 1) ? " occurrence was" : " occurrences were") + " deleted successfully.");
            } else {
                System.out.println("No equivalent customer feedback was found !!!");
            }

            // Response timer stop
            stopTime = System.nanoTime();

            // Display response time
            System.out.println("Response time:- " + String.format("%,d",stopTime-startTime) + " nanoseconds\n");

        }
    }
}