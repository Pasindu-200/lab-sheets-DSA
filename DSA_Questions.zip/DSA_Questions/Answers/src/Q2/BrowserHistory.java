package Q2;

import Q1.StackArray;

public class BrowserHistory {
        public static void main(String[] args) {
            StackArray history = new StackArray(5);
            int[] pages = {101, 102, 103, 104, 105};

            // Simulate visiting pages
            for (int page : pages) {
                history.push(page);
            }
            history.display();

            history.push(106);


            System.out.println("Pressing back button...");
            int removedPage = history.pop();
            System.out.println("Removed Page: " + removedPage);


            history.display();


            System.out.println("Top Page: " + history.peek());
        }
    }



