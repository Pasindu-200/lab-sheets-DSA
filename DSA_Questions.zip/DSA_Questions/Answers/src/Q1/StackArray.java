package Q1;

public class StackArray {
        private int maxSize;
        private int[] stackData;
        private int top;

        public StackArray(int s) {
            maxSize = s;
            stackData = new int[maxSize];
            top = -1;
        }

        public void push(int j) {
            if (isFull()) {
                System.out.println("Stack is full! Cannot push " + j);
                return;
            }
            stackData[++top] = j;
        }

        public int pop() {
            if (isEmpty()) {
                System.out.println("Stack is empty! Cannot pop.");
                return -1;
            }
            return stackData[top--];
        }

        public int peek() {
            if (isEmpty()) {
                System.out.println("Stack is empty! No top element.");
                return -1;
            }
            return stackData[top];
        }

        public boolean isEmpty() {
            return (top == -1);
        }

        public boolean isFull() {
            return (top == maxSize - 1);
        }

        public void display() {
            System.out.print("Current Stack: ");
            for (int i = 0; i <= top; i++) {
                System.out.print(stackData[i] + " ");
            }
            System.out.println();
        }

        public static void main(String[] args) {
            StackArray stack = new StackArray(6);
            int[] values = {10, 20, 30, 40, 50, 60};
            for (int value : values) {
                stack.push(value);
            }
            stack.display();
        }
    }

