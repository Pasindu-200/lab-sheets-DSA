package Q3;

import java.util.Stack;

public class RestaurantPlateManagement {
        public static void main(String[] args) {
            Stack<String> plates = new Stack<>();
            int maxSize = 5;
            int plateNumber = 101;


            for (int i = 0; i < 5; i++) {
                String plate = "Plate " + plateNumber++;
                plates.push(plate);
                System.out.println("Added " + plate);
            }

            
            if (plates.size() >= maxSize) {
                System.out.println("Stack is full! Cannot add Plate 106");
            }


            System.out.print("Current Stack: ");
            for (String plate : plates) System.out.print(plate + " ");
            System.out.println();


            String served = plates.pop();
            System.out.println("Serving: Removed " + served);


            System.out.print("Current Stack: ");
            for (String plate : plates) System.out.print(plate + " ");
            System.out.println();


            System.out.println("Top Plate: " + plates.peek());
        }
    }


