package Q4;

import java.util.Stack;

public class LibraryBookReturns {
        public static void main(String[] args) {
            Stack<String> bookStack = new Stack<>();


            bookStack.push("Data Structures and Algorithms");
            bookStack.push("Artificial Intelligence");
            bookStack.push("Operating Systems");
            System.out.println("Returned: \"Data Structures and Algorithms\"");
            System.out.println("Returned: \"Artificial Intelligence\"");
            System.out.println("Returned: \"Operating Systems\"");


            String shelved = bookStack.pop();
            System.out.println("Shelving: Removed \"" + shelved + "\"");


            System.out.print("Current Stack: [");
            for (int i = 0; i < bookStack.size(); i++) {
                System.out.print("\"" + bookStack.get(i) + "\"");
                if (i < bookStack.size() - 1) System.out.print(", ");
            }
            System.out.println("]");


            System.out.println("Top Book: \"" + bookStack.peek() + "\"");
        }
    }



