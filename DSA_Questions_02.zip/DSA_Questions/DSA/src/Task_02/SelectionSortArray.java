package Task_02;

import java.util.Random;

class SelectionSortArray {
    private long[] a;
    private int nElems;

    public SelectionSortArray(int size) {
        a = new long[size];
        nElems = 0;
    }


    public void insert(long value) {
        if (nElems < a.length) {
            a[nElems] = value;
            nElems++;
        } else {
            System.out.println("Array is full, cannot insert more elements.");
        }
    }

    public void selectionSort() {
        for (int i = 0; i < nElems - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < nElems; j++) {
                if (a[j] < a[minIndex]) {
                    minIndex = j;
                }
            }
            swap(i, minIndex);
        }
    }

    private void swap(int i, int j) {
        long temp = a[i];
        a[i] = a[j];
        a[j] = temp;
    }

    public void display() {
        for (int i = 0; i < nElems; i++) {
            System.out.print(a[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {

        SelectionSortArray productPrices = new SelectionSortArray(12);
        long[] prices = {1200, 850, 1999, 750, 1600, 950, 650, 1800, 2200, 1050, 1400, 1750};

        for (long price : prices) {
            productPrices.insert(price);
        }


        System.out.println("Product prices before sorting:");
        productPrices.display();


        long startTime = System.nanoTime();
        productPrices.selectionSort();
        long endTime = System.nanoTime();


        System.out.println("Product prices after sorting:");
        productPrices.display();


        System.out.println("Execution time for Selection Sort: " + (endTime - startTime) / 1_000_000.0 + " ms");


        System.out.println("Lowest price: " + prices[0]);
        System.out.println("Highest price: " + prices[prices.length - 1]);


        System.out.println("\nPerformance Analysis:");
        System.out.println("Best-case scenario: When the array is already sorted. Time Complexity: O(n²)");
        System.out.println("Worst-case scenario: When the array is sorted in reverse order. Time Complexity: O(n²)");
    }
}
