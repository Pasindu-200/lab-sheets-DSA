package Q2;
public class Action {
    String type;  // Either "type" or "delete"
    String value; // Word typed or character deleted

    public Action(String type, String value) {
        this.type = type;
        this.value = value;
    }
}
