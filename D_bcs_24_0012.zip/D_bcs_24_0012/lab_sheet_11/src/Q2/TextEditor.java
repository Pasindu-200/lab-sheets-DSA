package Q2;

import java.util.Scanner;

public class TextEditor {
    public static void main(String[] args) {
        Stack actionStack = new Stack(10); // Initialize a stack with a size of 10
        String text = "";

        // Simulating actions
        Action action1 = new Action("type", "Hello");
        actionStack.push(action1);
        text += action1.value;
        System.out.println("Text: " + text);

        Action action2 = new Action("type", " World");
        actionStack.push(action2);
        text += action2.value;
        System.out.println("Text: " + text);

        Action action3 = new Action("delete", "d");
        actionStack.push(action3);
        text = text.substring(0, text.length() - 1);
        System.out.println("Text: " + text);

        Action action4 = new Action("type", "!");
        actionStack.push(action4);
        text += action4.value;
        System.out.println("Text: " + text);

        // Undo functionality (up to 3 times)
        Scanner sc = new Scanner(System.in);
        for (int i = 0; i < 3; i++) {
            System.out.println("\nPress 'u' to Undo: ");
            String undoCommand = sc.nextLine();
            if (undoCommand.equals("u")) {
                Action lastAction = actionStack.pop();
                if (lastAction != null) {
                    if (lastAction.type.equals("type")) {
                        text = text.substring(0, text.length() - lastAction.value.length());
                    } else if (lastAction.type.equals("delete")) {
                        text += lastAction.value;
                    }
                    System.out.println("Text after Undo: " + text);
                }
            }
        }
    }
}

