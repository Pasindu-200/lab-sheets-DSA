package Q2;

public class Stack {
    private Action[] stackArray;
    private int top;

    public Stack(int size) {
        stackArray = new Action[size];
        top = -1;
    }

    public void push(Action action) {
        if (top < stackArray.length - 1) {
            stackArray[++top] = action;
        } else {
            System.out.println("Stack overflow!");
        }
    }

    public Action pop() {
        if (top >= 0) {
            return stackArray[top--];
        }
        System.out.println("Stack underflow!");
        return null;
    }

    public void displayActions() {
        if (top == -1) {
            System.out.println("No actions to display.");
        } else {
            for (int i = 0; i <= top; i++) {
                System.out.println("Action Type: " + stackArray[i].type + ", Value: " + stackArray[i].value);
            }
        }
    }
}
