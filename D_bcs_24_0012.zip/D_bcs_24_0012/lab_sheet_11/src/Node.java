public class Node {
    public int data;
    public Node next;
    public Node(int item){
        this.data=item;
        this.next=null;
    }
    public void displayNode(){
        System.out.println(this.data+"");
    }
}
