//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
Stack s=new Stack();
  s.push(800);
        s.push(700);
        s.push(600);
        s.push(500);
        s.push(400);
        s.push(300);
        s.display();
        s.pop();

    }
}