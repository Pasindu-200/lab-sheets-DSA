public class Stack {

    private Node top;

    public Stack(){
        top=null;
    }

    public void push(int value){
        Node newnode=new Node(value);
        if(isEmpty()){
            newnode.next=null;
        } else {
            newnode.next=top;
        }
        top=newnode;
    }

    private boolean isEmpty(){
       return(top==null);
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("stack is empty");
            return -1;
        }
        Node temp = top;
        while (temp != null) {
            temp = temp.next;
        }
        return temp.data;
    }

    public int peek(){
        if(isEmpty()){
            System.out.println("stack is empty");
            return-1;
        }
            return top.data;
        }public void display(){
        if(isEmpty()){
            System.out.println("stack is empty");
            return;
        }
        Node temp=top;
        while(temp!=null){
            System.out.println(temp.data+"");
            temp=temp.next;
        }
    }
    }


