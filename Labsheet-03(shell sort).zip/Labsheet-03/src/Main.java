//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void shellSort(int[] arr) {
     int a= arr.length;
     // 01 first start with the biggest gap
        for(int gap=a/2;gap>0;gap/=2){
            for(int i=gap; i<a;i++){
                int temp=arr[i];
                int j;
                for(j=i; j>=gap && arr[j-gap]>temp; j-=gap){
                    arr[j]=arr[j-gap];

                }
                arr[j]=temp;
            }
        }

        }
        public static void printArray(int[]arr){
        for(int value:arr){
            System.out.println(value +"");
        }
            System.out.println();
        }
        public static void main(String[]args){
        int[] arr={64,34,25,12,22,11,90};
            System.out.println("original array:");
            printArray(arr);
            shellSort(arr);
            System.out.println("Sorted array:");
            printArray(arr);
        }
    }
