package Q_02;


    public class StudentManager {
        // Shell Sort by marks in descending order
        public void shellSortByMarks(Student[] students) {
            int n = students.length;
            for (int gap = n / 2; gap > 0; gap /= 2) {
                for (int i = gap; i < n; i++) {
                    Student temp = students[i];
                    int j;
                    for (j = i; j >= gap && students[j - gap].marks < temp.marks; j -= gap) {
                        students[j] = students[j - gap];
                    }
                    students[j] = temp;
                }
            }
        }}

