package Q_02;
import java.util.Scanner;
public class Main {
    public static int binarySearchByIndex(Student[] students, int targetIndex) {
        int left = 0, right = students.length - 1;
        while (left <= right) {
            int mid = (left + right) / 2;
            if (students[mid].indexNumber == targetIndex) {
                return mid;
            } else if (students[mid].indexNumber < targetIndex) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return -1; // Not found
    }
public static void main(String[] args) {
    StudentManager M= new StudentManager();
    Scanner sc = new Scanner(System.in);

    // Step 1: Input student records
    System.out.print("Enter the number of students: ");
    int n = sc.nextInt();
    sc.nextLine(); // consume newline

    Student[] students = new Student[n];

    for (int i = 0; i < n; i++) {
        System.out.println("\nEnter details for Student " + (i + 1));
        System.out.print("Index Number: ");
        int index = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Marks: ");
        float marks = sc.nextFloat();
        students[i] = new Student(index, name, marks);
    }

    // Step 2: Sort students by marks in descending order
    M.shellSortByMarks(students);

    // Step 3: Display sorted list
    System.out.println("\n--- Sorted Student List (By Marks - Descending) ---");
    for (Student student : students) {
        System.out.println("Marks: " + student.marks + ", Name: " + student.name + ", Index: " + student.indexNumber);
    }

    // Step 4: Binary search by index number
    System.out.print("\nEnter an index number to search for: ");
    int searchIndex = sc.nextInt();

    // Sort again by index number for binary search
    // Use a copy of array to not lose sorted marks order
    Student[] sortedByIndex = students.clone();

    // Sort by index for binary search
    for (int gap = n / 2; gap > 0; gap /= 2) {
        for (int i = gap; i < n; i++) {
            Student temp = sortedByIndex[i];
            int j;
            for (j = i; j >= gap && sortedByIndex[j - gap].indexNumber > temp.indexNumber; j -= gap) {
                sortedByIndex[j] = sortedByIndex[j - gap];
            }
            sortedByIndex[j] = temp;
        }
    }

    int result = binarySearchByIndex(sortedByIndex, searchIndex);
    if (result != -1) {
        System.out.println("\nStudent found:");
        sortedByIndex[result].display();
    } else {
        System.out.println("\nStudent with index number " + searchIndex + " not found.");
    }

    sc.close();
}}


