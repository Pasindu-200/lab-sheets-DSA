package Q_02;

import java.util.Scanner;

class Student {
    int indexNumber;
    String name;
    float marks;

    public Student(int indexNumber, String name, float marks) {
        this.indexNumber = indexNumber;
        this.name = name;
        this.marks = marks;
    }

    public void display() {
        System.out.println("Index Number: " + indexNumber + ", Name: " + name + ", Marks: " + marks);
    }
}


